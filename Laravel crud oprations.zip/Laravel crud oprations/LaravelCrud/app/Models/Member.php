<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Member extends Model
{
    use HasFactory;
    protected $primaryKey = "member_id";
    function getgroup(){
        return $this->hasOne('App\Models\group','group_id');
    }

    public function getgroups(){
        return $this->hasMany('App\Models\group','group_id','group_id');
    }
}
