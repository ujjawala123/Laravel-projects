<?php

use App\Http\Controllers\ProductController;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\IndexController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/Products/index',[ProductController::class,'index'] )->name('products.index');
Route::get('/Products/create',[ProductController::class,'create'] )->name('products.create');
Route::post('/Products/store',[ProductController::class,'store'] )->name('products.store');

Route::get('/Products/{id}/edit',[ProductController::class,'edit'] );
Route::put('/Products/{id}/update',[ProductController::class,'update'] );

Route::get('/Products/{id}/delete',[ProductController::class,'destroy'] );

//sessions started
Route::get('get-all-session',function(){
    $session = session()->all();
    p($session);
});
//protected
Route::get('/data',[IndexController::class,'index'] )->middleware('gaurd');
Route::get('/group',[IndexController::class,'group'] )->middleware('gaurd');

Route::get('/no-access', function(){
    echo"you are allow to access the page";
    die;
});

Route::get('/profile', function(){
    echo"you are Welcome page";
    
});