<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\product;
use Faker\Factory as faker;

class ProductsSeeder extends Seeder
{
    /**
    * @return void
     * Run the database seeds.
     */
    public function run(): void
    
    {   for($i=1; $i<=3; $i++){      //fake data print in loop
        $faker =Faker::create();    ///fake data entries
        $product= new Product;
        $product->name =$faker->name;
        $product->description = "Faker data";
        $product->image = "2.jpg";
        
        $product->save();

    }
    }
}
