<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.14.3/dist/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.1.3/dist/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
  </body>
</html>
    <title>Laravel CRUD</title>
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light bg-dark">
  <a class="navbar-brand text-light" href="#">Navbar</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item ">
        <a class="nav-link text-light" href="/Products/index">Products</a>
      </li>
      <li class="nav-item">
        <a class="nav-link text-light" href="/Products/create">Create</a>
      </li>
    
      <li class="nav-item">
        <a class="nav-link text-light" href="/Products/index">Edit </a>
      </li>
      <li class="nav-item">
        <a class="nav-link text-light" href="/Products/index">Delete </a>
      </li>
    </ul>
    <form class="form-inline my-2 my-lg-0">
      <input class="form-control mr-sm-2 text-dark" type="search" placeholder="Search by name" aria-label="Search">
      <button class="btn btn-outline-light my-2 my-sm-0 text-light" type="submit">Search</button>
    </form>
  </div>
</nav>
    <div class="container">
       <div class="text-right">
        <a href="/Products/create" class="btn btn-dark mt-3">New Product</a>
       </div>
        
        <div class="container mt-5">
  
            
  <table class="table table-striped">
    <thead>
      <tr>
        <th>Sr.No</th>
        <th>Name</th>
        <th>Image</th>
        <th>Action</th>
      </tr>
    </thead>
    <tbody>
       @foreach($products as $product) 
       <tr>
        <td>{{$loop->index+1}}</td>
        <td>{{$product->name}}</td>
        <td>
          <img src="/products/{{$product->image}}" class="rounded-circle" width="60" height="60"/>
        </td> 
        <td>
          
          <a href="/Products/{{$product->id}}/edit" class="btn btn-success ">Edit</a>
          <a href="/Products/{{$product->id}}/delete" class="btn btn-danger ">Delete</a>

        </td> 
      @endforeach
      </tr>
      
    </tbody>
  </table>
  <div class="row">
    {{$products->links()}}
  </div>
</div>
    </div>
    
</body>
</html>